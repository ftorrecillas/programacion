
package HERENCIA;

public enum format {

    wav, mp3, midi, avi, mov, mpg, cdAudio, dvd
}
