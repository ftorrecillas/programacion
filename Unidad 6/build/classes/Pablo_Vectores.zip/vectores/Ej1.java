/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vectores;

/**
 *
 * @author mati
 */
public class Ej1 {
    //inicialización e instancia
    public static void main (String args[]) {
    int [] vector= new int [10];
    //inicialización, instancia y rellenado
    int [] vector01= {5,4,5,7,4,1,2,7,22,66};
    for (int i=0; vector01.length>i; i++ )
        System.out.println("El vector es: "+ vector01[i] );

    }
}
